#!/bin/sh
autoreconf -i -v -f
